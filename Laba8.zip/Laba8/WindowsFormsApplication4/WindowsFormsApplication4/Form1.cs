﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double p = 0.6;
        double alpha;
        Random r = new Random();
        string[] predicts = { "ТОЧНО НЕТ", "ЖЭБЭ", "ТОЧНО ДА", "Нет.", "Мб", "Отмена действию", "С пивом потянет", "Не стоит......."  };
        double[] maybe = { 0.125, 0.125, 0.125, 0.125, 0.125, 0.125, 0.125, 0.125};

        private void PredictBall_Click(object sender, EventArgs e)
        {
            alpha = r.NextDouble();
            double A = alpha;
            int k = 0;

            while(A> 0)
            {
                A -= maybe[k];
                k++;
            }
            textBox3.Text = predicts[k-1];
        }

        private void YesNo_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            alpha = r.NextDouble();
            if (alpha < p) { textBox2.Text = "Nope"; }
            else { textBox2.Text = "Yeah"; }

        }
    }

    
}
