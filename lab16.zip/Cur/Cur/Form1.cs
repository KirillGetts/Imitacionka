﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cur
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        const double k = 0.05;
        int day = 0;
        double rate, prev_rate;
        double mu = 0.00003, sigma = 0.009;
        int amount;
        int i = 0;
        double rubles = 10000;
        int dollars = 0;
        private void btStart_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            rate = Convert.ToDouble(textBox1.Text); 
            amount = (int)edAmount.Value;
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(0, rate);

            day++;
            prev_rate = rate;

            rate = prev_rate * Math.Exp((mu - sigma * sigma / (double)2) + sigma * (2*random.NextDouble()-1) ); 

            chart1.Series[0].Points.AddXY(day, rate);
            textBox1.Text = rate.ToString("F2");
            textBox2.Text = rubles.ToString("F2");
            textBox3.Text = dollars.ToString();
            i--;
        }

        private void button1_Click(object sender, EventArgs e) // купить
        {
            amount = (int)edAmount.Value;
            if (rubles >= amount * rate)
            {
                dollars += amount;
                rubles -= amount * rate;
                textBox2.Text = rubles.ToString("F2");
                textBox3.Text = dollars.ToString();
                textBox4.Text = "Операция прошла успешно";
            }
            else
            {
                textBox4.Text = "Недостаточно средств для проведения операции";
            }
        }

        private void button2_Click(object sender, EventArgs e) // продать
        {
            amount = (int)edAmount.Value;
            if (dollars >=amount)
            {
                dollars -= amount;
                rubles += amount * rate;
                textBox2.Text = rubles.ToString("F2");
                textBox3.Text = dollars.ToString();
                textBox4.Text = "Операция прошла успешно";
            }
            else
            {
                textBox4.Text = "Недостаточно средств для проведения операции";
            }
        }
    }
}
