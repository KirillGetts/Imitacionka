﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Team[] liga; int r1, r2;
        private void button1_Click(object sender, EventArgs e)
        {
            int N = 14;
            liga = new Team[N];
            liga[0] = new Team("Bayern Munchen          ", 4);
            liga[1] = new Team("RasenBallsport Leipzig  ", 4);
            liga[2] = new Team("Wolfsburg               ", 4);
            liga[3] = new Team("Borussia Dortmund       ", 3);
            liga[4] = new Team("Bayer 04                ", 2);
            liga[5] = new Team("Eintracht Frankfurt     ", 1);
            liga[6] = new Team("Union Berlin            ", 0);
            liga[7] = new Team("Borussia M              ", 2);
            liga[8] = new Team("Stuttgart               ", 2);
            liga[9] = new Team("Freiburg                ", 2);
            liga[10] = new Team("Hoffenheim              ", 1);
            liga[11] = new Team("Augsburg                ", 1);
            liga[12] = new Team("Mainz 05                ", 2);
            liga[13] = new Team("Hertha                  ", 2);


            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    if (i != j) { 
                         r1 = poisson(liga[i].el); r2 = poisson(liga[j].el);
                         if (r1 > r2) { liga[i].SetScore(r1); liga[i].Win(); liga[j].SetScore(r2); liga[j].Lose(); }
                         if (r1 < r2) { liga[j].SetScore(r2); liga[j].Win(); liga[i].SetScore(r1); liga[i].Lose(); }
                         if (r1 == r2) { liga[j].SetScore(r2); liga[i].Draw(); liga[i].SetScore(r1); liga[j].Draw(); }
                         liga[i].setDifference(r1 - r2);
                         liga[j].setDifference(r2 - r1);
                    }
                }
            }

            sort(liga, N);

            textBox1.Clear();
            textBox1.AppendText("Название команды\t\t Очки\t\t Победы\t\t Поражения\t\t Ничьи\t\t Разница мячей\n");
            for (int i =0; i<N; i++)
            {
                textBox1.AppendText(liga[i].Name);
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].score.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].winCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].loseCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].drawCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].differenceCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText("\n");

            }
        }

        int poisson(int l)
        {
            Random rnd = new Random();
            double sum = 0; int i;
            for (i = -1; sum >= -l; i++) sum += Math.Log(rnd.NextDouble());
            return i;
        }

        void sort(Team[] teams, int size)
        {
            Team temp;
            temp = new Team(" ", 0);
            for (int i = 0; i < size - 1; i++)
            {
                for (int j = 0; j < size - i - 1; j++)
                {
                    if (teams[j].score < teams[j + 1].score)
                    {
                        // меняем элементы местами
                        temp = teams[j];
                        teams[j] = teams[j + 1];
                        teams[j + 1] = temp;
                    }
                }
            }
        }

        class Team
        {
            public string Name;
            public int score;
            public int el;
            public int winCount;
            public int loseCount;
            public int drawCount;
            public int differenceCount;

            public Team(string name, int l)
            {
                Name = name;
                score = 0;
                el = l;
                winCount = 0;
                loseCount = 0;
                drawCount = 0;
                differenceCount = 0;
            }

            public void SetScore(int i)
            {
                score += i;
            }

            public void setDifference(int i)
            {
                differenceCount += i;
            }
            public void Win()
            {
                winCount++;
            }
            public void Lose()
            {
                loseCount++;
            }
            public void Draw()
            {
                drawCount++;
            }
        }
    }
}
