﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Team[] liga; int r1, r2;
        private void button1_Click(object sender, EventArgs e)
        {
            int N = 14;
            liga = new Team[N];
            liga[0] = new Team("Bayern Munchen          ", 4);
            liga[1] = new Team("RasenBallsport Leipzig  ", 4);
            liga[2] = new Team("Wolfsburg               ", 3);
            liga[3] = new Team("Borussia Dortmund       ", 3);
            liga[4] = new Team("Bayer 04                ", 3);
            liga[5] = new Team("Eintracht Frankfurt     ", 3);
            liga[6] = new Team("Union Berlin            ", 2);
            liga[7] = new Team("Borussia M              ", 2);
            liga[8] = new Team("Stuttgart               ", 2);
            liga[9] = new Team("Freiburg                ", 2);
            liga[10] = new Team("Hoffenheim              ", 2);
            liga[11] = new Team("Augsburg                ", 1);
            liga[12] = new Team("Mainz 05                ", 1);
            liga[13] = new Team("Hertha                  ", 1);


            for (int i = 0; i < N - 1; i++)
            {
                for (int j = i + 1; j < N; j++)
                {
                    r1 = poisson(liga[i].el); r2 = poisson(liga[j].el);
                    if (r1 > r2) { liga[i].SetScore(3); liga[i].Win(); liga[j].SetScore(0); liga[j].Lose();}
                    if (r1 < r2) { liga[j].SetScore(3); liga[j].Win(); liga[i].SetScore(0); liga[i].Lose(); }
                    if (r1 == r2) { liga[j].SetScore(1); liga[i].Draw(); liga[i].SetScore(1); liga[j].Draw(); }
                    liga[i].setDifference(r1 - r2);
                    liga[j].setDifference(r2 - r1);
                }
            }

            sort(liga, N);

            // как-то вывести в форму
            textBox1.Clear();
            textBox1.AppendText("Название команды\t\t Очки\t\t Победы\t\t Поражения\t\t Ничьи\t\t Разница мячей\n");
            for (int i =0; i<N; i++)
            {
                textBox1.AppendText(liga[i].Name);
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].score.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].winCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].loseCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].drawCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText(liga[i].differenceCount.ToString());
                textBox1.AppendText("\t\t ");
                textBox1.AppendText("\n");

            }



            // рейтинговая система
            //
            // определить набор команд в лиге
            // каждая играет с каждой
            // у каждой команды есть средняя интенсивность количества голов за матч
            // в каждом матче рандомно генерируется количество голов каждой команды
            // если победа, то команде +3, ничья +1, поражение - 0
            //
            // составляем таблицу с баллами
            // сортируем по убыванию
            // [0] - победитель

        }

        int poisson(double l)
        {
            Random r = new Random();
            int m = -1; double S = 0;
            do
            {
                m++;
                S += Math.Log(r.NextDouble());
            } while (!(S < -l));
            return m;
        }

        void sort(Team[] teams, int size)
        {
            Team temp;
            temp = new Team(" ", 0);
            for (int i = 0; i < size - 1; i++)
            {
                for (int j = 0; j < size - i - 1; j++)
                {
                    if (teams[j].score < teams[j + 1].score)
                    {
                        // меняем элементы местами
                        temp.Name = teams[j].Name; temp.score = teams[j].score; temp.el = teams[j].el; temp.winCount = teams[j].winCount; temp.loseCount = teams[j].loseCount; temp.drawCount = teams[j].drawCount; temp.differenceCount = teams[j].differenceCount;
                        teams[j].Name = teams[j + 1].Name; teams[j].score = teams[j + 1].score; teams[j].el = teams[j + 1].el; teams[j].winCount = teams[j + 1].winCount; teams[j].loseCount = teams[j + 1].loseCount; teams[j].drawCount = teams[j + 1].drawCount; teams[j].differenceCount = teams[j + 1].differenceCount;
                        teams[j + 1].Name = teams[j].Name; teams[j + 1].score = teams[j].score; teams[j + 1].el = teams[j].el; teams[j + 1].winCount = teams[j].winCount; teams[j + 1].loseCount = teams[j].loseCount; teams[j + 1].drawCount = teams[j].drawCount; teams[j + 1].differenceCount = teams[j].differenceCount;

                    }
                }
            }
        }

        class Team
        {
            public string Name;
            public int score;
            public int el;
            public int winCount;
            public int loseCount;
            public int drawCount;
            public int differenceCount;

            public Team(string name, int l)
            {
                Name = name;
                score = 0;
                el = l;
                winCount = 0;
                loseCount = 0;
                drawCount = 0;
                differenceCount = 0;
            }

            public void SetScore(int i)
            {
                score += i;
            }

            public void setDifference(int i)
            {
                differenceCount += i;
            }
            public void Win()
            {
                winCount++;
            }
            public void Lose()
            {
                loseCount++;
            }
            public void Draw()
            {
                drawCount++;
            }
        }
    }
}
