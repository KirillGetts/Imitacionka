﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flight
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const double dt = 0.1;
        Athmosphere atm = new Athmosphere();
        Object ob = new Object();

        double k;
        double t;
       
        private void btStart_Click(object sender, EventArgs e)
        {
            ob.a = (double)edAngle.Value;
            ob.v0 = (double)edSpeed.Value;
            ob.y0 = (double)edHeight.Value;
            ob.m = (double)edWeight.Value;
            ob.S = (double)edSquare.Value;
            k = 0.5 * atm.C * ob.S * atm.rho / ob.m;

            ob.y = ob.y0;
            ob.VX(); ob.VY();

            t = 0;
            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(ob.x, ob.y);

            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            t += dt;
            ob.NextVX(k, dt);
            ob.NextVY(k, dt, atm);

            ob.NextX(dt); ob.NextY(dt);

            chart1.Series[0].Points.AddXY(ob.x, ob.y);
            if (ob.y <= 0) {
                ob.nullify();
                timer1.Stop();
            }
        }
    }

    public class Athmosphere
    {
        public double C; 
        public double rho; 
        public double g;

        public Athmosphere()
        {
            C = 0.15;
            rho = 1.29;
            g = 9.81;
        }
    }

    public class Object
    {
            public double m;
            public double S;
            public double v0;
            public double a;
            public double y0;
            public double vx;
            public double vy;
            public double x;
            public double y;



            public Object() 
            {
                a = 0;
                v0 = 0;
                y0 = 0;
                m = 0;
                S = 0;
                vx = 0;
                vy = 0;
                x = 0;
                y = y0;
            }

        
            public void VX()
            {
                this.vx = v0 * Math.Cos(a * Math.PI / 180);
            }

            public void VY()
            {
                this.vy = v0 * Math.Sin(a * Math.PI / 180);
            }

            public void NextVX(double k, double dt)
            {
                this.vx = vx - k * vx * Math.Sqrt(vx * vx + vy * vy) * dt;
            }
            public void NextVY(double k, double dt, Athmosphere a)
            {
                this.vy = vy - (a.g + k * vy * Math.Sqrt(vx * vx + vy * vy)) * dt;
            }

            public void NextX(double dt)
            {
                this.x = x + vx * dt;

            }

            public void NextY(double dt)
            {
                this.y = y + vy * dt;

            }

        public void nullify()
        {
            this.x = 0;
            this.y = 0;
        }

    }

    
}
