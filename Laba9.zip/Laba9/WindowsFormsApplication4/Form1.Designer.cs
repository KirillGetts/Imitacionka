﻿namespace WindowsFormsApplication4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbt4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.prob4e = new System.Windows.Forms.TextBox();
            this.prob3e = new System.Windows.Forms.TextBox();
            this.prob2e = new System.Windows.Forms.TextBox();
            this.prob1e = new System.Windows.Forms.TextBox();
            this.Generate = new System.Windows.Forms.Button();
            this.tbt1 = new System.Windows.Forms.NumericUpDown();
            this.tbt2 = new System.Windows.Forms.NumericUpDown();
            this.tbt3 = new System.Windows.Forms.NumericUpDown();
            this.tbN = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbt1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbN)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(337, 54);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.IsVisibleInLegend = false;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(529, 423);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Prob 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Prob 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Prob 3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 120);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Prob 4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Number of experiments";
            // 
            // tbt4
            // 
            this.tbt4.Location = new System.Drawing.Point(75, 117);
            this.tbt4.Name = "tbt4";
            this.tbt4.ReadOnly = true;
            this.tbt4.Size = new System.Drawing.Size(100, 20);
            this.tbt4.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(94, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Theoretical";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(223, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Experimental";
            // 
            // prob4e
            // 
            this.prob4e.Location = new System.Drawing.Point(204, 117);
            this.prob4e.Name = "prob4e";
            this.prob4e.ReadOnly = true;
            this.prob4e.Size = new System.Drawing.Size(100, 20);
            this.prob4e.TabIndex = 15;
            // 
            // prob3e
            // 
            this.prob3e.Location = new System.Drawing.Point(204, 85);
            this.prob3e.Name = "prob3e";
            this.prob3e.ReadOnly = true;
            this.prob3e.Size = new System.Drawing.Size(100, 20);
            this.prob3e.TabIndex = 14;
            // 
            // prob2e
            // 
            this.prob2e.Location = new System.Drawing.Point(204, 54);
            this.prob2e.Name = "prob2e";
            this.prob2e.ReadOnly = true;
            this.prob2e.Size = new System.Drawing.Size(100, 20);
            this.prob2e.TabIndex = 13;
            // 
            // prob1e
            // 
            this.prob1e.Location = new System.Drawing.Point(204, 24);
            this.prob1e.Name = "prob1e";
            this.prob1e.ReadOnly = true;
            this.prob1e.Size = new System.Drawing.Size(100, 20);
            this.prob1e.TabIndex = 12;
            // 
            // Generate
            // 
            this.Generate.Location = new System.Drawing.Point(75, 203);
            this.Generate.Name = "Generate";
            this.Generate.Size = new System.Drawing.Size(173, 94);
            this.Generate.TabIndex = 17;
            this.Generate.Text = "Generate";
            this.Generate.UseVisualStyleBackColor = true;
            this.Generate.Click += new System.EventHandler(this.Generate_Click);
            // 
            // tbt1
            // 
            this.tbt1.DecimalPlaces = 3;
            this.tbt1.Location = new System.Drawing.Point(74, 24);
            this.tbt1.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.tbt1.Name = "tbt1";
            this.tbt1.Size = new System.Drawing.Size(101, 20);
            this.tbt1.TabIndex = 18;
            // 
            // tbt2
            // 
            this.tbt2.DecimalPlaces = 3;
            this.tbt2.Location = new System.Drawing.Point(74, 55);
            this.tbt2.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.tbt2.Name = "tbt2";
            this.tbt2.Size = new System.Drawing.Size(101, 20);
            this.tbt2.TabIndex = 19;
            // 
            // tbt3
            // 
            this.tbt3.DecimalPlaces = 3;
            this.tbt3.Location = new System.Drawing.Point(74, 86);
            this.tbt3.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.tbt3.Name = "tbt3";
            this.tbt3.Size = new System.Drawing.Size(101, 20);
            this.tbt3.TabIndex = 20;
            // 
            // tbN
            // 
            this.tbN.Location = new System.Drawing.Point(143, 152);
            this.tbN.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.tbN.Name = "tbN";
            this.tbN.Size = new System.Drawing.Size(94, 20);
            this.tbN.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 683);
            this.Controls.Add(this.tbN);
            this.Controls.Add(this.tbt3);
            this.Controls.Add(this.tbt2);
            this.Controls.Add(this.tbt1);
            this.Controls.Add(this.Generate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.prob4e);
            this.Controls.Add(this.prob3e);
            this.Controls.Add(this.prob2e);
            this.Controls.Add(this.prob1e);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tbt4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chart1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbt1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbN)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbt4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox prob4e;
        private System.Windows.Forms.TextBox prob3e;
        private System.Windows.Forms.TextBox prob2e;
        private System.Windows.Forms.TextBox prob1e;
        private System.Windows.Forms.Button Generate;
        private System.Windows.Forms.NumericUpDown tbt1;
        private System.Windows.Forms.NumericUpDown tbt2;
        private System.Windows.Forms.NumericUpDown tbt3;
        private System.Windows.Forms.NumericUpDown tbN;
    }
}

