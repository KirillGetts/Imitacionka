﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        int N;
        int[] statistics;
        double[] prob, probEx;
        double a;
        Random random = new Random();

        private void Generate_Click(object sender, EventArgs e)
        {
            statistics = new int[4];
            prob = new double[4];
            probEx = new double[4];
            for (int i = 0; i < 4; i++) statistics[i] = 0;

            N = (int)tbN.Value;
            prob[0] = (double)tbt1.Value;
            prob[1] = (double)tbt2.Value;
            prob[2] = (double)tbt3.Value;
            prob[3] = 1 - prob[0] - prob[1] - prob[2];
            tbt4.Text = prob[3].ToString();

            for(int i =0; i<N; i++)
            {
                a = random.NextDouble();
                double summ = 0;
                for(int k =0; k<4; k++)
                {
                    summ += prob[k];
                    if (a<= summ) { statistics[k]++; break; }
                }

            }

            for(int i =0; i<4; i++)
            {
                probEx[i] = statistics[i] / (double)N;
            }

            prob1e.Text = probEx[0].ToString("F3");
            prob2e.Text = probEx[1].ToString("F3");
            prob3e.Text = probEx[2].ToString("F3");
            prob4e.Text = probEx[3].ToString("F3");


            chart1.Series[0].Points.Clear();
            for(int i =0; i<4; i++)
            chart1.Series[0].Points.AddXY(i, probEx[i]);

            // график
        }
    }
}
