﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int n = 10;
        string[] states = { "ясно", "облачно", "пасмурно" }; string state0;
        double[] dur = { 0, 0, 0}; double SumDur = 0;
        int i, inew, j, k; double t, tnew, tau;
        Random a = new Random();
        double[,] Q;
        int I, J; int hours; double p, p1, r;

        private void button1_Click(object sender, EventArgs e)
        {
            hours = 0;
                // считать начальное состояние
            state0 = (string)comboBox1.SelectedItem;
            for ( k =0; k<3; k++)
            {
                if (states[k].Equals(state0)) I = k;
            }
            
            // задать переход состояний
            Q = new double[3, 3];

            Q[0, 0] = -0.4; Q[0, 1] = 0.3; Q[0, 2] = 0.1;
            Q[1, 0] = 0.2; Q[1, 1] = -0.5; Q[1, 2] = 0.3;
            Q[2, 0] = 0.1; Q[2, 1] = 0.2; Q[2, 2] = -0.3;

            // нанести на график первое состояние

            chart1.Series[0].Points.Clear();
            chart1.Series[0].Points.AddXY(0, I);
            //
            // генерировать случайную величину
            t = 0;

            while (hours <= 24)
            {
                // в какой момент времени перешли в другое состояние
                tau = Math.Log(a.NextDouble()) / Q[I, I];
                t += tau;

                // в какое состояние перешли
                p1 = 0;
                r = a.NextDouble();
                for (j = 0; j<3; j++)
                {
                    if (j == I) { p = 0; }
                    else { p = -Q[I, j] / Q[I, I]; }
                    p1 += p;
                       if ( r < p1) { I = j; break; }
                }

                 if (t >= n)
                 {
                     tbHour.Text = hours++.ToString();
                     chart1.Series[0].Points.AddXY(hours, I);
                     t = 0;
                 }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            state0 = (string)comboBox1.SelectedItem;
            for (k = 0; k < 3; k++)
            {
                if (states[k].Equals(state0)) I = k;
            }
            Q = new double[3, 3];

            Q[0, 0] = -0.4; Q[0, 1] = 0.3; Q[0, 2] = 0.1;
            Q[1, 0] = 0.2; Q[1, 1] = -0.5; Q[1, 2] = 0.3;
            Q[2, 0] = 0.1; Q[2, 1] = 0.2; Q[2, 2] = -0.3;

            double T = 1000;
            t = 0;
            while (t <= T)
            {
                // в какой момент времени перешли в другое состояние
                tau = Math.Log(a.NextDouble()) / Q[I, I];
                t += tau;

                // в какое состояние перешли
                p1 = 0;
                r = a.NextDouble();
                for (j = 0; j < 3; j++)
                {
                    if (j == I) { p = 0; }
                    else { p = -Q[I, j] / Q[I, I]; }
                    p1 += p;
                    if (r < p1) { I = j; break; }
                }
            }
            k = 0;
            tnew = t; inew = I;
            while(k< n)
            {
                // в какой момент времени перешли в другое состояние
                tau = Math.Log(a.NextDouble()) / Q[I, I];
                tnew += tau;

                // в какое состояние перешли
                p1 = 0;
                r = a.NextDouble();
                for (j = 0; j < 3; j++)
                {
                    if (j == I) { p = 0; }
                    else { p = -Q[I, j] / Q[I, I]; }
                    p1 += p;
                    if (r < p1) { I = j; break; }
                }
                k++;

                dur[I] += (tnew - t);
                I = inew; t = tnew;
            }
            for (i = 0; i < 3; i++) dur[i] = dur[i] / dur.Sum();

            chart2.Series[0].Points.Clear();
            for (i = 0; i < 3; i++) chart2.Series[0].Points.AddXY(i, dur[i]);
        }
    }
}
