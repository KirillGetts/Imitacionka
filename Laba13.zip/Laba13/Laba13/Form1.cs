﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Laba13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int N, n; double p, M, M_emp, D, D_emp, errorM, errorD;
        int[] stat; int[] line; double[] freq;
        Random R = new Random();

        private void button1_Click(object sender, EventArgs e)
        {
            N = int.Parse((string)cb1.SelectedItem);
            p = (double)prob.Value;

            n = (int)(1+3.322 * Math.Log(N));
            stat = new int[n]; for (int i = 0; i < n; i++) stat[i] = 0;
            line = new int[N]; freq = new double[n];

            for (int i=0; i<N; i++)
            {
                line[i] = (int)(Math.Log(R.NextDouble()) / Math.Log(1 - p));
            }

          double d = (line.Max() - line.Min()) / n;
            int delta = (int)Math.Ceiling(d);

            M = (1-p) /p;
            D = (1 - p) / (p * p);
            M_emp =0;
            for (int i =0; i<N; i++)
            {
                M_emp += line[i] * probability(line[i]);
            }
            D_emp = 0;
            for (int i = 0; i < N; i++)
            {
                D_emp += line[i] * line[i] * probability(line[i]);
            }
            D_emp -= M_emp;

            tbM.Text = M_emp.ToString("F3");
            tbD.Text = D_emp.ToString("F3");
            errorM = Math.Abs((M - M_emp) / M);
            tbErM.Text = errorM.ToString("F3");
            errorD = Math.Abs((D - D_emp) / D);
            tbErD.Text = errorD.ToString("F3");

            for(int i =0; i<N; i++)
            {
                stat[line[i]]++;
            }

            double[] chi = { 14.067, 24.996 };
            int m = 1;
            if (N == 10) m = 0;
            double X = 0;
            for(int i =0; i<n; i++)
            {
                X += (stat[i] * stat[i]) / (probability(i) * N);
            }

            X -= N;
            if (X < chi[m]) tbTest.Text = "True";
            else tbTest.Text = "False";



            for (int i = 0; i < n; i++) freq[i] = (double)stat[i] / (double)N;
            chart1.Series[0].Points.Clear();
            for (int i = 0; i < n; i++) chart1.Series[0].Points.AddXY(i + 1, freq[i]);
        }
        double probability(int a)
        {
            double l = 1;
            for (int i = 0; i < a; i++)
            {
                l *= 1 - p;
            }
            return p * l;
        }

        void sort(int first, int last)
        {
            double p = line[(last - first) / 2 + first];
            int temp;
            int i = first, j = last;
            while (i <= j)
            {
                while (line[i] < p && i <= last) ++i;
                while (line[j] > p && j >= first) --j;
                if (i <= j)
                {
                    temp = line[i];
                    line[i] = line[j];
                    line[j] = temp;
                    ++i; --j;
                }
            }
            if (j > first) sort(first, j);
            if (i < last) sort(i, last);
        }

    }
    
}
